/**
 * Created by luke on 2/07/17.
 */
function update_filter() {
    alert("update filter function")
}