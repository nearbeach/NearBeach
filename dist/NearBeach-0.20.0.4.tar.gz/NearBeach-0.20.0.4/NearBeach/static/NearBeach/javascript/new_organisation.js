void function add_https() {
    /*
    When the user clicks on the organisation's website field, we want to add
    https:// at the start automatically. This is so that the customer does not
    need to enter in this required string. We only need to do this when there
    is nothing in the field
     */

}

void function paste_url() {
    /*
    When the user pastes a URL we want to double check it so that it will pass
    the validation of the form.
     */

}