# Contributing to NearBeach 
Welcome to NearBeach, we are an Open Source project management tool. We welcome all different types of contributes from but not limited to;
- Code patches
- Bug reports and patch reviews
- Documentation imparovements
- Feature requests/ideas/improvements

Please fork NearBeach, git your changes in and then submit a simple pull request. Not all pull requests will be accepted.
